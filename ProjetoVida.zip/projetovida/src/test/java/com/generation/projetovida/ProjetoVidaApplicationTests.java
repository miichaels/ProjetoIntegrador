package com.generation.projetovida;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoVidaApplicationTests {

	@Test
	void contextLoads() {
	}

}
