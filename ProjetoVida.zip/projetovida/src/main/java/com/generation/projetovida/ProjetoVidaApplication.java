package com.generation.projetovida;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoVidaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoVidaApplication.class, args);
	}

}
